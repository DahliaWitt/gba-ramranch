Ram Ranch: The Game
Author: Drake Witt

The game is a basic shooter game. Try not to get hit by the trucks. Press button A to shoot at the trucks.
If the trucks hit you, you die.

Controls:
Gameboy
Start
Select
A
B
L
R
Keyboard
Enter
Backspace
Z
X
A
S

Start the game by pressing enter.