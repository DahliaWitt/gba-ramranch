/*
 * Exported with nin10kit v1.7
 * Time-stamp: Thursday 04/11/2019, 04:23:51
 * 
 * Image Information
 * -----------------
 * /cs2110/host/hw/gba-ramranch/images/fordraptor.png 76@37
 * /cs2110/host/hw/gba-ramranch/images/rootytootypointnshooty.png 40@48
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ROOTYTOOTYPOINTNSHOOTY_H
#define ROOTYTOOTYPOINTNSHOOTY_H

extern const unsigned short rootytootypointnshooty[1920];
#define ROOTYTOOTYPOINTNSHOOTY_SIZE 3840
#define ROOTYTOOTYPOINTNSHOOTY_LENGTH 1920
#define ROOTYTOOTYPOINTNSHOOTY_WIDTH 40
#define ROOTYTOOTYPOINTNSHOOTY_HEIGHT 48

#endif

