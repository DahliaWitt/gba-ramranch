/*
 * Exported with nin10kit v1.7
 * Time-stamp: Wednesday 04/10/2019, 03:52:11
 * 
 * Image Information
 * -----------------
 * /home/drakewitt/Documents/ramranch.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RAMRANCH_H
#define RAMRANCH_H

extern const unsigned short ramranch[38400];
#define RAMRANCH_SIZE 76800
#define RAMRANCH_LENGTH 38400
#define RAMRANCH_WIDTH 240
#define RAMRANCH_HEIGHT 160

#endif

