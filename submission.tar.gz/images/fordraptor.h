/*
 * Exported with nin10kit v1.7
 * Time-stamp: Thursday 04/11/2019, 04:40:33
 * 
 * Image Information
 * -----------------
 * /cs2110/host/hw/gba-ramranch/images/fordraptor.png 76@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FORDRAPTOR_H
#define FORDRAPTOR_H

extern const unsigned short fordraptor[2812];
#define FORDRAPTOR_SIZE 5624
#define FORDRAPTOR_LENGTH 2812
#define FORDRAPTOR_WIDTH 76
#define FORDRAPTOR_HEIGHT 37

#endif

