// ../sounddata sound made by wav2c

// const int ../sounddata_sampleRate = 8000;
#define ramranch_length 520516

extern const signed char ramranch_data[];