//
// Created by Drake Witt on 2019-04-10.
//

#ifndef GBA_RAMRANCH_TITLESCREEN_H
#define GBA_RAMRANCH_TITLESCREEN_H

extern int flashText;
void drawTitleScreen(void);
void startTextFlash(void);

#endif //GBA_RAMRANCH_TITLESCREEN_H
